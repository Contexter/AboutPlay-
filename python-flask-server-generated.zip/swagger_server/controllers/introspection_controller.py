import connexion
import six

from swagger_server import util


def root_get():  # noqa: E501
    """OpenAPI description (this document)

     # noqa: E501


    :rtype: None
    """
    return 'do some magic!'
