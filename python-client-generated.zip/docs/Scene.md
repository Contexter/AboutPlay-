# Scene

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scene_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**act_id** | **int** | Note: This is a Foreign Key to &#x60;act.act_id&#x60;.&lt;fk table&#x3D;&#x27;act&#x27; column&#x3D;&#x27;act_id&#x27;/&gt; | [optional] 
**scene_number** | **int** |  | 
**synopsis** | **str** |  | [optional] 
**notes** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

