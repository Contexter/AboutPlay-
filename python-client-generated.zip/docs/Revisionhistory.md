# Revisionhistory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**revision_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**script_id** | **int** | Note: This is a Foreign Key to &#x60;script.script_id&#x60;.&lt;fk table&#x3D;&#x27;script&#x27; column&#x3D;&#x27;script_id&#x27;/&gt; | [optional] 
**_date** | **date** |  | [optional] 
**change_description** | **str** |  | [optional] 
**editor** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

