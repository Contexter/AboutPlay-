# Casting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**casting_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**character_id** | **int** | Note: This is a Foreign Key to &#x60;character.character_id&#x60;.&lt;fk table&#x3D;&#x27;character&#x27; column&#x3D;&#x27;character_id&#x27;/&gt; | [optional] 
**actor_characteristics_choices** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

