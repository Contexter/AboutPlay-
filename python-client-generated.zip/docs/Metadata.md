# Metadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metadata_id** | **int** | Note: This is a Primary Key.&lt;pk/&gt; | 
**creation_date** | **date** |  | [optional] 
**last_modified_date** | **date** |  | [optional] 
**version_number** | **int** |  | [optional] 
**additional_information** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

